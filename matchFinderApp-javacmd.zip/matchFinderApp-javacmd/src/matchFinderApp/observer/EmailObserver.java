package src.matchFinderApp.observer;

import java.util.Map;

public class EmailObserver extends Observer {

    public EmailObserver(String recipent){
        super.setRecipient(recipent);
    }



    @Override
    public void update(Map<String, String> leaguesMatches) {

    }
}
