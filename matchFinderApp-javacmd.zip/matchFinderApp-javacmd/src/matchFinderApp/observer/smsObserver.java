package src.matchFinderApp.observer;

import src.matchFinderApp.SmsSender;

import java.util.Map;

public class smsObserver extends Observer {
    
public smsObserver(String recipient){
super.setRecipient(recipient);
}


    @Override
    public void update(Map<String, String> leaguesMatches) {
        SmsSender.Send(leaguesMatches);
    }
}
