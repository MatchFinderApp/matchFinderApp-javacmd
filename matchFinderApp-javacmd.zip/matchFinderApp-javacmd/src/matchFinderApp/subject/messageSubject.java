package src.matchFinderApp.subject;

import src.matchFinderApp.observer.Observer;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class messageSubject implements subject{
//We will imlements the method at the next stage


// Add observer object to the list of observers to be notified\

    List<Observer> observers;
    public messageSubject(){
        this.observers = new ArrayList<Observer>();
    }
    @Override
    public void addSubscriber(Observer Observer) {
       this.observers.add(Observer);
    }
    // remove observer object to the list of observers
    @Override
    public void removeSubscriber(Observer Observer) {
        this.observers.remove(Observer);
    }
    // notify observer
    @Override
    public void notifySubscribers(Map<String, String> leaguesMatches) {
        observers.getFirst().update(leaguesMatches);

    }
    
}
