package src.matchFinderApp.subject;

import src.matchFinderApp.observer.Observer;

import java.util.Map;

//Here is the Abstract Factory Design Pattern

public abstract interface subject {

    void addSubscriber(Observer Observer);
    void removeSubscriber(Observer Observer);
    void notifySubscribers(Map<String, String> leaguesMatches);
}
